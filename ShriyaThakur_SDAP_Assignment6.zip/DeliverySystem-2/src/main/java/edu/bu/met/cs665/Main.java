/**
 * Name: SHRIYA THAKUR
 * Course: CS-665 Software Designs & Patterns
 * Date: 10/06/2023
 * File Name: Main.java
 * Description: Main class for running application.
 */
package edu.bu.met.cs665;

import edu.bu.met.cs665.models.Driver;
import edu.bu.met.cs665.models.Scooter;
import edu.bu.met.cs665.models.Taxi;
import edu.bu.met.cs665.models.Van;
import edu.bu.met.cs665.models.Vehicle;
import edu.bu.met.cs665.services.Shop;

/**
 * This is the Main class.
 */
public class Main {

  /**
   * A main method to run examples.
   * You may use this method for development purposes as you start building your
   * assignments/final project.  This could prove convenient to test as you are developing.
   * However, please note that every assignment/final projects requires JUnit tests.
   */
  public static void main(String[] args) {
	  String product = "shoes";
	  String location = "Michigan";
	  
	  Vehicle scooter = new Scooter();
	  Vehicle van = new Van();
	  Vehicle taxi = new Taxi();
	  
	  Driver driverMike = new Driver(scooter);
	  Driver driverSteve = new Driver(van);
	  Driver driverJoe = new Driver(taxi);
	  Shop marketPlace = new Shop();
	  
	  // Testing main methods created for this project.
	  marketPlace.createDeliveryRequest(product, location);
	  marketPlace.registerObserver(driverJoe);
	  marketPlace.registerObserver(driverSteve);
	  marketPlace.registerObserver(driverMike);
	  
	  marketPlace.notifyObservers();
	  
	  System.out.println("Driver Mike: ");
	  System.out.println(driverMike.toString());
	  System.out.println(driverMike.getDeliveryRequest().toString());
	  System.out.println("Driver Steve: ");
	  System.out.println(driverSteve.toString());
	  System.out.println(driverSteve.getDeliveryRequest().toString());
	  System.out.println("Driver Joe: ");
	  System.out.println(driverJoe.toString());
	  System.out.println(driverJoe.getDeliveryRequest().toString());
  }

}
