/**
 * Name: SHRIYA THAKUR
 * Course: CS-665 Software Designs & Patterns
 * Date: 12/01/2023
 * File Name: Scooter.java
 * Description: Scooter class inherited from Vehicle.
 */
package edu.bu.met.cs665.models;

public class Scooter extends Vehicle {

	public Scooter() {
		super("Scooter");
	}

}
