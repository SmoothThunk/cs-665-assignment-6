/**
 * Name: SHRIYA THAKUR
 * Course: CS-665 Software Designs & Patterns
 * Date: 12/01/2023
 * File Name: Shop.java
 * Description: Shop acts a concrete Observable. Consists of list of observers (drivers).
 */
package edu.bu.met.cs665.services;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import edu.bu.met.cs665.models.DeliveryRequest;
import edu.bu.met.cs665.models.Observer;

public class Shop implements Observable {

	private List<Observer> drivers;
	private DeliveryRequest deliveryRequest;

	/**
	 * Instantiates empty list of drivers upon creation.
	 */
	public Shop() {
		super();
		this.drivers = new ArrayList<Observer>();
	}
	
	/**
	 * Get current delivery request.
	 * @return delivery request for shop.
	 */
	public DeliveryRequest getDeliveryRequest() {
		return deliveryRequest;
	}

	/**
	 * Registers an observer by adding driver to list of observers.
	 * @param driver for shop will observe new delivery requests.
	 */
	@Override
	public void registerObserver(Observer driver) {
		if (driver != null && !findDriver(driver)) {
			drivers.add(driver);
		} else {
			throw new IllegalArgumentException("Driver being registered to observer cannot be null or already be registered");
		}
	}

	/**
	 * Unregisters an observer by removing driver from list of observers.
	 * @param driver for shop will no longer observe new delivery requests.
	 */
	@Override
	public void unregisterObserver(Observer driver) {
		if (driver != null && findDriver(driver)) {
			drivers.remove(driver);
		} else {
			throw new IllegalArgumentException("Driver being unregistered from observer cannot be null or not exist");
		}
	}

	/**
	 * Notifies all drivers by iterating through list of observers and updating each with new delivery request.
	 */
	@Override
	public void notifyObservers() {
		if (drivers.isEmpty() || this.deliveryRequest == null) {
			throw new IllegalStateException("Cannot notify shop with no drivers or null delivery request");
		} else {
			for (Iterator<Observer> observer = drivers.iterator(); observer.hasNext();) {
				Observer driver = observer.next();
				driver.update(this.deliveryRequest);
			}
		}
	}
	
	/**
	 * Creates a new delivery request that assigned to shop.
	 * @param product for delivery request.
	 * @param location for delivery request.
	 */
	public void createDeliveryRequest(String product, String location) {
		if (product != null && location != null) {
			this.deliveryRequest = new DeliveryRequest(product, location);
		} else {
			throw new NullPointerException("product and location of delivery request cannot be null");
		}
	}
	
	/**
	 * 
	 * @param driver that has been registered.
	 * @return boolean that indicates whether driver is registered or not.
	 */
	public boolean findDriver(Observer driver) {
		return drivers.contains(driver);
	}

}
