/**
 * Name: SHRIYA THAKUR
 * Course: CS-665 Software Designs & Patterns
 * Date: 12/01/2023
 * File Name: Driver.java
 * Description: Driver class acts as concrete Observer. Driver consists of a single vehicle. 
 */
package edu.bu.met.cs665.models;

import java.util.Objects;

public class Driver implements Observer {
	
	private int id;
	private Vehicle vehicle;
	private DeliveryRequest deliveryRequest;

	public Driver(Vehicle vehicle) {
		this.id = IdGenerator.getInstance().getUniqueId();
		this.setVehicle(vehicle);
	}

	/**
	 * Updates driver with delivery request.
	 * @param deliveryRequest sets delivery request to driver.
	 */
	@Override
	public void update(DeliveryRequest deliveryRequest) {
		this.deliveryRequest = deliveryRequest;
	}
	
	public DeliveryRequest getDeliveryRequest() {
		return deliveryRequest;
	}

	public Vehicle getVehicle() {
		return vehicle;
	}

	public void setVehicle(Vehicle vehicle) {
		this.vehicle = vehicle;
	}

	@Override
	public int hashCode() {
		return Objects.hash(deliveryRequest, id, vehicle);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Driver other = (Driver) obj;
		return Objects.equals(deliveryRequest, other.deliveryRequest) && id == other.id
				&& Objects.equals(vehicle, other.vehicle);
	}

	@Override
	public String toString() {
		return "Driver [id=" + id + ", vehicle=" + vehicle + ", deliveryRequest=" + deliveryRequest + "]";
	}

}
