/**
 * Name: SHRIYA THAKUR
 * Course: CS-665 Software Designs & Patterns
 * Date: 12/01/2023
 * File Name: IdGenerator.java
 * Description: Generates a new ID per driver object created.
 */
package edu.bu.met.cs665.models;

public class IdGenerator {
	
	private static IdGenerator instance = null;
	private int nextId = 0;
	
	/**
	 * Creates static instance of ID generator.
	 * @return instance used to generate IDs.
	 */
	public static IdGenerator getInstance() {
		if (instance == null) {
			instance = new IdGenerator();
		}
		return instance;
	}

	/**
	 * Creates a new ID based on previous one assigned.
	 * @return uniqueId to be used.
	 */
	public int getUniqueId() {
		int uniqueId = nextId;
		nextId++;
		return uniqueId;
	}

}
