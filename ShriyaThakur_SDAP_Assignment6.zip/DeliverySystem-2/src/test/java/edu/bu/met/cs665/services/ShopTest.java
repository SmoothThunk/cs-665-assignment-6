/**
 * Name: SHRIYA THAKUR
 * Course: CS-665 Software Designs & Patterns
 * Date: 12/01/2023
 * File Name: ShopTest.java
 * Description: This is a test class for the Shop class.
 * This class is reponsible for:
 * - testing registering and unregistering observers
 * - testing creating a delivery request from Observable
 * - testing ability to notify all observers at once
 */
package edu.bu.met.cs665.services;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import edu.bu.met.cs665.models.DeliveryRequest;
import edu.bu.met.cs665.models.Driver;
import edu.bu.met.cs665.models.Scooter;
import edu.bu.met.cs665.models.Taxi;
import edu.bu.met.cs665.models.Van;
import edu.bu.met.cs665.models.Vehicle;

public class ShopTest {
	
	private Shop shop;

	private Driver driver1;
	private Driver driver2;
	private Driver driver3;
	private Driver driver4;
	private Driver driver5;
	
	private Vehicle scooter;
	private Vehicle van;
	private Vehicle taxi;
	
	@Before
	public void setUp() throws Exception {
		shop = new Shop();
		
		scooter = new Scooter();
		van = new Van();
		taxi = new Taxi();
		
		driver1 = new Driver(scooter);
		driver2 = new Driver(van);
		driver3 = new Driver(taxi);
		driver4 = new Driver(scooter);
		driver5 = new Driver(van);
	}
	
	/**
	 * Tests registering a driver to the Observable. 
	 */
	@Test
	public void testRegisterObserver_Success() {
		shop.registerObserver(driver1);
		assertTrue(shop.findDriver(driver1));
	}
	
	/**
	 * Tests that an error is thrown when registering a null driver.
	 */
	@Test
	public void testRegisterObserver_Failure_NonExistantDriver() {
		
		Exception ex = assertThrows(IllegalArgumentException.class, () -> {
			shop.registerObserver(null);
		});
		
		assertEquals(ex.getMessage(), "Driver being registered to observer cannot be null or already be registered");
	}
	
	/**
	 * Tests unregistering a driver to the Observable.
	 */
	@Test
	public void testUnregisterObserver_Success() {
		shop.registerObserver(driver1);
		shop.registerObserver(driver2);
		shop.unregisterObserver(driver1);
		
		assertFalse(shop.findDriver(driver1));
	}
	
	/**
	 * Tests that an error is thrown when attempting to unregister a non-registered driver.
	 */
	@Test
	public void testUnregisterObserver_Failure_NonExistantDriver() {
		
		Exception ex = assertThrows(IllegalArgumentException.class, () -> {
			shop.unregisterObserver(driver1);
		});
		
		assertEquals(ex.getMessage(), "Driver being unregistered from observer cannot be null or not exist");
	}
	
	/**
	 * Tests that an error is thrown when attempting to notify observers when no drivers are registered to the shop.
	 */
	@Test
	public void testNotifyObservers_Failure_NoRegisteredDrivers() {
		
		shop.createDeliveryRequest("Jump Rope", "New Mexico");
		
		Exception ex = assertThrows(IllegalStateException.class, () -> {
			shop.notifyObservers();
		});
		
		assertEquals(ex.getMessage(), "Cannot notify shop with no drivers or null delivery request");
	}
	
	/**
	 * Tests that an error is thrown when attempting to notify observers when there is no delivery request set.
	 */
	@Test
	public void testNotifyObservers_Failure_NoDeliveryRequest() {
		
		shop.registerObserver(driver1);
		
		Exception ex = assertThrows(IllegalStateException.class, () -> {
			shop.notifyObservers();
		});
		
		assertEquals(ex.getMessage(), "Cannot notify shop with no drivers or null delivery request");
	}
	
	/**
	 * Tests that an error is thrown when attempting to create a delivery requests with null parameters.
	 */
	@Test
	public void testCreateDeliveryRequest_Failure_NullRequest() {
		
		// Checks with just item set to null.
		Exception ex = assertThrows(NullPointerException.class, () -> {
			shop.createDeliveryRequest(null, "Location");
		});
		
		// Checks with just location set to null.
		Exception ex1 = assertThrows(NullPointerException.class, () -> {
			shop.createDeliveryRequest("Item", null);
		});
		
		// Checks with both item and location set to null.
		Exception ex2 = assertThrows(NullPointerException.class, () -> {
			shop.createDeliveryRequest(null, null);
		});
		
		assertEquals(ex.getMessage(), "product and location of delivery request cannot be null");
		assertEquals(ex1.getMessage(), "product and location of delivery request cannot be null");
		assertEquals(ex2.getMessage(), "product and location of delivery request cannot be null");
	}
	
	/**
	 * Tests all methods from Observable at once.
	 */
	@Test
	public void testAllMethods_Success() {
		// Test delivery request.
		DeliveryRequest expectedDeliveryRequest = new DeliveryRequest("Bicycle", "New Jersey");

		// Register 5 Driver objects to Observable .
		shop.registerObserver(driver1);
		shop.registerObserver(driver2);
		shop.registerObserver(driver3);
		shop.registerObserver(driver4);
		shop.registerObserver(driver5);
		
		// Create a new delivery request and notify all drivers.
		shop.createDeliveryRequest("Bicycle", "New Jersey");
		shop.notifyObservers();
		
		// Unregister 3 Driver objects.
		shop.unregisterObserver(driver1);
		shop.unregisterObserver(driver2);
		shop.unregisterObserver(driver5);
		
		// Create a new delivery request and notify remaining registered drivers.
		shop.createDeliveryRequest("Unicycle", "New York");
		shop.notifyObservers();
		
		// Drivers 1, 2, and 3 became unregistered from the Observable after 
		// first delivery request so they were not notified of most recent delivery request.
		assertEquals(expectedDeliveryRequest, driver1.getDeliveryRequest());
		assertEquals(expectedDeliveryRequest, driver2.getDeliveryRequest()); 
		assertEquals(expectedDeliveryRequest, driver5.getDeliveryRequest());
		// Drivers 4, 5 remained registered, newest request does not match the expected request.
		assertNotEquals(expectedDeliveryRequest, driver3.getDeliveryRequest());
		assertNotEquals(expectedDeliveryRequest, driver4.getDeliveryRequest());
	}

}
